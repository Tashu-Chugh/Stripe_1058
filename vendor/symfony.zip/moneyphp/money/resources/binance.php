<?php return array (
  '1INCH' => 
  array (
    'symbol' => '1INCH',
    'minorUnit' => 8,
  ),
  'AAVE' => 
  array (
    'symbol' => 'AAVE',
    'minorUnit' => 8,
  ),
  'ACA' => 
  array (
    'symbol' => 'ACA',
    'minorUnit' => 8,
  ),
  'ACH' => 
  array (
    'symbol' => 'ACH',
    'minorUnit' => 8,
  ),
  'ACM' => 
  array (
    'symbol' => 'ACM',
    'minorUnit' => 8,
  ),
  'ADA' => 
  array (
    'symbol' => 'ADA',
    'minorUnit' => 8,
  ),
  'ADX' => 
  array (
    'symbol' => 'ADX',
    'minorUnit' => 8,
  ),
  'AERGO' => 
  array (
    'symbol' => 'AERGO',
    'minorUnit' => 8,
  ),
  'AGIX' => 
  array (
    'symbol' => 'AGIX',
    'minorUnit' => 8,
  ),
  'AGLD' => 
  array (
    'symbol' => 'AGLD',
    'minorUnit' => 8,
  ),
  'AION' => 
  array (
    'symbol' => 'AION',
    'minorUnit' => 8,
  ),
  'AKRO' => 
  array (
    'symbol' => 'AKRO',
    'minorUnit' => 8,
  ),
  'ALCX' => 
  array (
    'symbol' => 'ALCX',
    'minorUnit' => 8,
  ),
  'ALGO' => 
  array (
    'symbol' => 'ALGO',
    'minorUnit' => 8,
  ),
  'ALICE' => 
  array (
    'symbol' => 'ALICE',
    'minorUnit' => 8,
  ),
  'ALPACA' => 
  array (
    'symbol' => 'ALPACA',
    'minorUnit' => 8,
  ),
  'ALPHA' => 
  array (
    'symbol' => 'ALPHA',
    'minorUnit' => 8,
  ),
  'ALPINE' => 
  array (
    'symbol' => 'ALPINE',
    'minorUnit' => 8,
  ),
  'AMB' => 
  array (
    'symbol' => 'AMB',
    'minorUnit' => 8,
  ),
  'AMP' => 
  array (
    'symbol' => 'AMP',
    'minorUnit' => 8,
  ),
  'ANC' => 
  array (
    'symbol' => 'ANC',
    'minorUnit' => 8,
  ),
  'ANKR' => 
  array (
    'symbol' => 'ANKR',
    'minorUnit' => 8,
  ),
  'ANT' => 
  array (
    'symbol' => 'ANT',
    'minorUnit' => 8,
  ),
  'APE' => 
  array (
    'symbol' => 'APE',
    'minorUnit' => 8,
  ),
  'API3' => 
  array (
    'symbol' => 'API3',
    'minorUnit' => 8,
  ),
  'APT' => 
  array (
    'symbol' => 'APT',
    'minorUnit' => 8,
  ),
  'AR' => 
  array (
    'symbol' => 'AR',
    'minorUnit' => 8,
  ),
  'ARDR' => 
  array (
    'symbol' => 'ARDR',
    'minorUnit' => 8,
  ),
  'ARK' => 
  array (
    'symbol' => 'ARK',
    'minorUnit' => 8,
  ),
  'ARPA' => 
  array (
    'symbol' => 'ARPA',
    'minorUnit' => 8,
  ),
  'ASR' => 
  array (
    'symbol' => 'ASR',
    'minorUnit' => 8,
  ),
  'AST' => 
  array (
    'symbol' => 'AST',
    'minorUnit' => 8,
  ),
  'ASTR' => 
  array (
    'symbol' => 'ASTR',
    'minorUnit' => 8,
  ),
  'ATA' => 
  array (
    'symbol' => 'ATA',
    'minorUnit' => 8,
  ),
  'ATM' => 
  array (
    'symbol' => 'ATM',
    'minorUnit' => 8,
  ),
  'ATOM' => 
  array (
    'symbol' => 'ATOM',
    'minorUnit' => 8,
  ),
  'AUCTION' => 
  array (
    'symbol' => 'AUCTION',
    'minorUnit' => 8,
  ),
  'AUDIO' => 
  array (
    'symbol' => 'AUDIO',
    'minorUnit' => 8,
  ),
  'AUTO' => 
  array (
    'symbol' => 'AUTO',
    'minorUnit' => 8,
  ),
  'AVA' => 
  array (
    'symbol' => 'AVA',
    'minorUnit' => 8,
  ),
  'AVAX' => 
  array (
    'symbol' => 'AVAX',
    'minorUnit' => 8,
  ),
  'AXS' => 
  array (
    'symbol' => 'AXS',
    'minorUnit' => 8,
  ),
  'BADGER' => 
  array (
    'symbol' => 'BADGER',
    'minorUnit' => 8,
  ),
  'BAKE' => 
  array (
    'symbol' => 'BAKE',
    'minorUnit' => 8,
  ),
  'BAL' => 
  array (
    'symbol' => 'BAL',
    'minorUnit' => 8,
  ),
  'BAND' => 
  array (
    'symbol' => 'BAND',
    'minorUnit' => 8,
  ),
  'BAR' => 
  array (
    'symbol' => 'BAR',
    'minorUnit' => 8,
  ),
  'BAT' => 
  array (
    'symbol' => 'BAT',
    'minorUnit' => 8,
  ),
  'BCH' => 
  array (
    'symbol' => 'BCH',
    'minorUnit' => 8,
  ),
  'BDOT' => 
  array (
    'symbol' => 'BDOT',
    'minorUnit' => 8,
  ),
  'BEAM' => 
  array (
    'symbol' => 'BEAM',
    'minorUnit' => 8,
  ),
  'BEL' => 
  array (
    'symbol' => 'BEL',
    'minorUnit' => 8,
  ),
  'BETA' => 
  array (
    'symbol' => 'BETA',
    'minorUnit' => 8,
  ),
  'BETH' => 
  array (
    'symbol' => 'BETH',
    'minorUnit' => 8,
  ),
  'BICO' => 
  array (
    'symbol' => 'BICO',
    'minorUnit' => 8,
  ),
  'BIDR' => 
  array (
    'symbol' => 'BIDR',
    'minorUnit' => 8,
  ),
  'BIFI' => 
  array (
    'symbol' => 'BIFI',
    'minorUnit' => 8,
  ),
  'BLZ' => 
  array (
    'symbol' => 'BLZ',
    'minorUnit' => 8,
  ),
  'BNB' => 
  array (
    'symbol' => 'BNB',
    'minorUnit' => 8,
  ),
  'BNT' => 
  array (
    'symbol' => 'BNT',
    'minorUnit' => 8,
  ),
  'BNX' => 
  array (
    'symbol' => 'BNX',
    'minorUnit' => 8,
  ),
  'BOND' => 
  array (
    'symbol' => 'BOND',
    'minorUnit' => 8,
  ),
  'BSW' => 
  array (
    'symbol' => 'BSW',
    'minorUnit' => 8,
  ),
  'BTC' => 
  array (
    'symbol' => 'BTC',
    'minorUnit' => 8,
  ),
  'BTCST' => 
  array (
    'symbol' => 'BTCST',
    'minorUnit' => 8,
  ),
  'BTS' => 
  array (
    'symbol' => 'BTS',
    'minorUnit' => 8,
  ),
  'BTTC' => 
  array (
    'symbol' => 'BTTC',
    'minorUnit' => 8,
  ),
  'BURGER' => 
  array (
    'symbol' => 'BURGER',
    'minorUnit' => 8,
  ),
  'BUSD' => 
  array (
    'symbol' => 'BUSD',
    'minorUnit' => 8,
  ),
  'C98' => 
  array (
    'symbol' => 'C98',
    'minorUnit' => 8,
  ),
  'CAKE' => 
  array (
    'symbol' => 'CAKE',
    'minorUnit' => 8,
  ),
  'CELO' => 
  array (
    'symbol' => 'CELO',
    'minorUnit' => 8,
  ),
  'CELR' => 
  array (
    'symbol' => 'CELR',
    'minorUnit' => 8,
  ),
  'CFX' => 
  array (
    'symbol' => 'CFX',
    'minorUnit' => 8,
  ),
  'CHESS' => 
  array (
    'symbol' => 'CHESS',
    'minorUnit' => 8,
  ),
  'CHR' => 
  array (
    'symbol' => 'CHR',
    'minorUnit' => 8,
  ),
  'CHZ' => 
  array (
    'symbol' => 'CHZ',
    'minorUnit' => 8,
  ),
  'CITY' => 
  array (
    'symbol' => 'CITY',
    'minorUnit' => 8,
  ),
  'CKB' => 
  array (
    'symbol' => 'CKB',
    'minorUnit' => 8,
  ),
  'CLV' => 
  array (
    'symbol' => 'CLV',
    'minorUnit' => 8,
  ),
  'COCOS' => 
  array (
    'symbol' => 'COCOS',
    'minorUnit' => 8,
  ),
  'COMP' => 
  array (
    'symbol' => 'COMP',
    'minorUnit' => 8,
  ),
  'COS' => 
  array (
    'symbol' => 'COS',
    'minorUnit' => 8,
  ),
  'COTI' => 
  array (
    'symbol' => 'COTI',
    'minorUnit' => 8,
  ),
  'CREAM' => 
  array (
    'symbol' => 'CREAM',
    'minorUnit' => 8,
  ),
  'CRV' => 
  array (
    'symbol' => 'CRV',
    'minorUnit' => 8,
  ),
  'CTK' => 
  array (
    'symbol' => 'CTK',
    'minorUnit' => 8,
  ),
  'CTSI' => 
  array (
    'symbol' => 'CTSI',
    'minorUnit' => 8,
  ),
  'CTXC' => 
  array (
    'symbol' => 'CTXC',
    'minorUnit' => 8,
  ),
  'CVC' => 
  array (
    'symbol' => 'CVC',
    'minorUnit' => 8,
  ),
  'CVP' => 
  array (
    'symbol' => 'CVP',
    'minorUnit' => 8,
  ),
  'CVX' => 
  array (
    'symbol' => 'CVX',
    'minorUnit' => 8,
  ),
  'DAI' => 
  array (
    'symbol' => 'DAI',
    'minorUnit' => 8,
  ),
  'DAR' => 
  array (
    'symbol' => 'DAR',
    'minorUnit' => 8,
  ),
  'DASH' => 
  array (
    'symbol' => 'DASH',
    'minorUnit' => 8,
  ),
  'DATA' => 
  array (
    'symbol' => 'DATA',
    'minorUnit' => 8,
  ),
  'DCR' => 
  array (
    'symbol' => 'DCR',
    'minorUnit' => 8,
  ),
  'DEGO' => 
  array (
    'symbol' => 'DEGO',
    'minorUnit' => 8,
  ),
  'DENT' => 
  array (
    'symbol' => 'DENT',
    'minorUnit' => 8,
  ),
  'DEXE' => 
  array (
    'symbol' => 'DEXE',
    'minorUnit' => 8,
  ),
  'DF' => 
  array (
    'symbol' => 'DF',
    'minorUnit' => 8,
  ),
  'DGB' => 
  array (
    'symbol' => 'DGB',
    'minorUnit' => 8,
  ),
  'DIA' => 
  array (
    'symbol' => 'DIA',
    'minorUnit' => 8,
  ),
  'DOCK' => 
  array (
    'symbol' => 'DOCK',
    'minorUnit' => 8,
  ),
  'DODO' => 
  array (
    'symbol' => 'DODO',
    'minorUnit' => 8,
  ),
  'DOGE' => 
  array (
    'symbol' => 'DOGE',
    'minorUnit' => 8,
  ),
  'DOT' => 
  array (
    'symbol' => 'DOT',
    'minorUnit' => 8,
  ),
  'DREP' => 
  array (
    'symbol' => 'DREP',
    'minorUnit' => 8,
  ),
  'DUSK' => 
  array (
    'symbol' => 'DUSK',
    'minorUnit' => 8,
  ),
  'DYDX' => 
  array (
    'symbol' => 'DYDX',
    'minorUnit' => 8,
  ),
  'EGLD' => 
  array (
    'symbol' => 'EGLD',
    'minorUnit' => 8,
  ),
  'ELF' => 
  array (
    'symbol' => 'ELF',
    'minorUnit' => 8,
  ),
  'ENJ' => 
  array (
    'symbol' => 'ENJ',
    'minorUnit' => 8,
  ),
  'ENS' => 
  array (
    'symbol' => 'ENS',
    'minorUnit' => 8,
  ),
  'EOS' => 
  array (
    'symbol' => 'EOS',
    'minorUnit' => 8,
  ),
  'EPX' => 
  array (
    'symbol' => 'EPX',
    'minorUnit' => 8,
  ),
  'ETC' => 
  array (
    'symbol' => 'ETC',
    'minorUnit' => 8,
  ),
  'ETH' => 
  array (
    'symbol' => 'ETH',
    'minorUnit' => 8,
  ),
  'FARM' => 
  array (
    'symbol' => 'FARM',
    'minorUnit' => 8,
  ),
  'FET' => 
  array (
    'symbol' => 'FET',
    'minorUnit' => 8,
  ),
  'FIDA' => 
  array (
    'symbol' => 'FIDA',
    'minorUnit' => 8,
  ),
  'FIL' => 
  array (
    'symbol' => 'FIL',
    'minorUnit' => 8,
  ),
  'FIO' => 
  array (
    'symbol' => 'FIO',
    'minorUnit' => 8,
  ),
  'FIRO' => 
  array (
    'symbol' => 'FIRO',
    'minorUnit' => 8,
  ),
  'FIS' => 
  array (
    'symbol' => 'FIS',
    'minorUnit' => 8,
  ),
  'FLM' => 
  array (
    'symbol' => 'FLM',
    'minorUnit' => 8,
  ),
  'FLOW' => 
  array (
    'symbol' => 'FLOW',
    'minorUnit' => 8,
  ),
  'FLUX' => 
  array (
    'symbol' => 'FLUX',
    'minorUnit' => 8,
  ),
  'FOR' => 
  array (
    'symbol' => 'FOR',
    'minorUnit' => 8,
  ),
  'FORTH' => 
  array (
    'symbol' => 'FORTH',
    'minorUnit' => 8,
  ),
  'FRONT' => 
  array (
    'symbol' => 'FRONT',
    'minorUnit' => 8,
  ),
  'FTM' => 
  array (
    'symbol' => 'FTM',
    'minorUnit' => 8,
  ),
  'FTT' => 
  array (
    'symbol' => 'FTT',
    'minorUnit' => 8,
  ),
  'FUN' => 
  array (
    'symbol' => 'FUN',
    'minorUnit' => 8,
  ),
  'FXS' => 
  array (
    'symbol' => 'FXS',
    'minorUnit' => 8,
  ),
  'GAL' => 
  array (
    'symbol' => 'GAL',
    'minorUnit' => 8,
  ),
  'GALA' => 
  array (
    'symbol' => 'GALA',
    'minorUnit' => 8,
  ),
  'GAS' => 
  array (
    'symbol' => 'GAS',
    'minorUnit' => 8,
  ),
  'GHST' => 
  array (
    'symbol' => 'GHST',
    'minorUnit' => 8,
  ),
  'GLM' => 
  array (
    'symbol' => 'GLM',
    'minorUnit' => 8,
  ),
  'GLMR' => 
  array (
    'symbol' => 'GLMR',
    'minorUnit' => 8,
  ),
  'GMT' => 
  array (
    'symbol' => 'GMT',
    'minorUnit' => 8,
  ),
  'GMX' => 
  array (
    'symbol' => 'GMX',
    'minorUnit' => 8,
  ),
  'GNO' => 
  array (
    'symbol' => 'GNO',
    'minorUnit' => 8,
  ),
  'GRT' => 
  array (
    'symbol' => 'GRT',
    'minorUnit' => 8,
  ),
  'GTC' => 
  array (
    'symbol' => 'GTC',
    'minorUnit' => 8,
  ),
  'GTO' => 
  array (
    'symbol' => 'GTO',
    'minorUnit' => 8,
  ),
  'HARD' => 
  array (
    'symbol' => 'HARD',
    'minorUnit' => 8,
  ),
  'HBAR' => 
  array (
    'symbol' => 'HBAR',
    'minorUnit' => 8,
  ),
  'HFT' => 
  array (
    'symbol' => 'HFT',
    'minorUnit' => 8,
  ),
  'HIGH' => 
  array (
    'symbol' => 'HIGH',
    'minorUnit' => 8,
  ),
  'HIVE' => 
  array (
    'symbol' => 'HIVE',
    'minorUnit' => 8,
  ),
  'HNT' => 
  array (
    'symbol' => 'HNT',
    'minorUnit' => 8,
  ),
  'HOOK' => 
  array (
    'symbol' => 'HOOK',
    'minorUnit' => 8,
  ),
  'HOT' => 
  array (
    'symbol' => 'HOT',
    'minorUnit' => 8,
  ),
  'ICP' => 
  array (
    'symbol' => 'ICP',
    'minorUnit' => 8,
  ),
  'ICX' => 
  array (
    'symbol' => 'ICX',
    'minorUnit' => 8,
  ),
  'IDEX' => 
  array (
    'symbol' => 'IDEX',
    'minorUnit' => 8,
  ),
  'IDRT' => 
  array (
    'symbol' => 'IDRT',
    'minorUnit' => 8,
  ),
  'ILV' => 
  array (
    'symbol' => 'ILV',
    'minorUnit' => 8,
  ),
  'IMX' => 
  array (
    'symbol' => 'IMX',
    'minorUnit' => 8,
  ),
  'INJ' => 
  array (
    'symbol' => 'INJ',
    'minorUnit' => 8,
  ),
  'IOST' => 
  array (
    'symbol' => 'IOST',
    'minorUnit' => 8,
  ),
  'IOTA' => 
  array (
    'symbol' => 'IOTA',
    'minorUnit' => 8,
  ),
  'IOTX' => 
  array (
    'symbol' => 'IOTX',
    'minorUnit' => 8,
  ),
  'IQ' => 
  array (
    'symbol' => 'IQ',
    'minorUnit' => 8,
  ),
  'IRIS' => 
  array (
    'symbol' => 'IRIS',
    'minorUnit' => 8,
  ),
  'JASMY' => 
  array (
    'symbol' => 'JASMY',
    'minorUnit' => 8,
  ),
  'JOE' => 
  array (
    'symbol' => 'JOE',
    'minorUnit' => 8,
  ),
  'JST' => 
  array (
    'symbol' => 'JST',
    'minorUnit' => 8,
  ),
  'JUV' => 
  array (
    'symbol' => 'JUV',
    'minorUnit' => 8,
  ),
  'KAVA' => 
  array (
    'symbol' => 'KAVA',
    'minorUnit' => 8,
  ),
  'KDA' => 
  array (
    'symbol' => 'KDA',
    'minorUnit' => 8,
  ),
  'KEY' => 
  array (
    'symbol' => 'KEY',
    'minorUnit' => 8,
  ),
  'KLAY' => 
  array (
    'symbol' => 'KLAY',
    'minorUnit' => 8,
  ),
  'KMD' => 
  array (
    'symbol' => 'KMD',
    'minorUnit' => 8,
  ),
  'KNC' => 
  array (
    'symbol' => 'KNC',
    'minorUnit' => 8,
  ),
  'KP3R' => 
  array (
    'symbol' => 'KP3R',
    'minorUnit' => 8,
  ),
  'KSM' => 
  array (
    'symbol' => 'KSM',
    'minorUnit' => 8,
  ),
  'LAZIO' => 
  array (
    'symbol' => 'LAZIO',
    'minorUnit' => 8,
  ),
  'LDO' => 
  array (
    'symbol' => 'LDO',
    'minorUnit' => 8,
  ),
  'LEVER' => 
  array (
    'symbol' => 'LEVER',
    'minorUnit' => 8,
  ),
  'LINA' => 
  array (
    'symbol' => 'LINA',
    'minorUnit' => 8,
  ),
  'LINK' => 
  array (
    'symbol' => 'LINK',
    'minorUnit' => 8,
  ),
  'LIT' => 
  array (
    'symbol' => 'LIT',
    'minorUnit' => 8,
  ),
  'LOKA' => 
  array (
    'symbol' => 'LOKA',
    'minorUnit' => 8,
  ),
  'LOOM' => 
  array (
    'symbol' => 'LOOM',
    'minorUnit' => 8,
  ),
  'LPT' => 
  array (
    'symbol' => 'LPT',
    'minorUnit' => 8,
  ),
  'LRC' => 
  array (
    'symbol' => 'LRC',
    'minorUnit' => 8,
  ),
  'LSK' => 
  array (
    'symbol' => 'LSK',
    'minorUnit' => 8,
  ),
  'LTC' => 
  array (
    'symbol' => 'LTC',
    'minorUnit' => 8,
  ),
  'LTO' => 
  array (
    'symbol' => 'LTO',
    'minorUnit' => 8,
  ),
  'LUNA' => 
  array (
    'symbol' => 'LUNA',
    'minorUnit' => 8,
  ),
  'LUNC' => 
  array (
    'symbol' => 'LUNC',
    'minorUnit' => 8,
  ),
  'MAGIC' => 
  array (
    'symbol' => 'MAGIC',
    'minorUnit' => 8,
  ),
  'MANA' => 
  array (
    'symbol' => 'MANA',
    'minorUnit' => 8,
  ),
  'MASK' => 
  array (
    'symbol' => 'MASK',
    'minorUnit' => 8,
  ),
  'MATIC' => 
  array (
    'symbol' => 'MATIC',
    'minorUnit' => 8,
  ),
  'MBL' => 
  array (
    'symbol' => 'MBL',
    'minorUnit' => 8,
  ),
  'MBOX' => 
  array (
    'symbol' => 'MBOX',
    'minorUnit' => 8,
  ),
  'MC' => 
  array (
    'symbol' => 'MC',
    'minorUnit' => 8,
  ),
  'MDT' => 
  array (
    'symbol' => 'MDT',
    'minorUnit' => 8,
  ),
  'MDX' => 
  array (
    'symbol' => 'MDX',
    'minorUnit' => 8,
  ),
  'MFT' => 
  array (
    'symbol' => 'MFT',
    'minorUnit' => 8,
  ),
  'MINA' => 
  array (
    'symbol' => 'MINA',
    'minorUnit' => 8,
  ),
  'MIR' => 
  array (
    'symbol' => 'MIR',
    'minorUnit' => 8,
  ),
  'MITH' => 
  array (
    'symbol' => 'MITH',
    'minorUnit' => 8,
  ),
  'MKR' => 
  array (
    'symbol' => 'MKR',
    'minorUnit' => 8,
  ),
  'MLN' => 
  array (
    'symbol' => 'MLN',
    'minorUnit' => 8,
  ),
  'MOB' => 
  array (
    'symbol' => 'MOB',
    'minorUnit' => 8,
  ),
  'MOVR' => 
  array (
    'symbol' => 'MOVR',
    'minorUnit' => 8,
  ),
  'MTL' => 
  array (
    'symbol' => 'MTL',
    'minorUnit' => 8,
  ),
  'MULTI' => 
  array (
    'symbol' => 'MULTI',
    'minorUnit' => 8,
  ),
  'NEAR' => 
  array (
    'symbol' => 'NEAR',
    'minorUnit' => 8,
  ),
  'NEBL' => 
  array (
    'symbol' => 'NEBL',
    'minorUnit' => 8,
  ),
  'NEO' => 
  array (
    'symbol' => 'NEO',
    'minorUnit' => 8,
  ),
  'NEXO' => 
  array (
    'symbol' => 'NEXO',
    'minorUnit' => 8,
  ),
  'NKN' => 
  array (
    'symbol' => 'NKN',
    'minorUnit' => 8,
  ),
  'NMR' => 
  array (
    'symbol' => 'NMR',
    'minorUnit' => 8,
  ),
  'NULS' => 
  array (
    'symbol' => 'NULS',
    'minorUnit' => 8,
  ),
  'OAX' => 
  array (
    'symbol' => 'OAX',
    'minorUnit' => 8,
  ),
  'OCEAN' => 
  array (
    'symbol' => 'OCEAN',
    'minorUnit' => 8,
  ),
  'OG' => 
  array (
    'symbol' => 'OG',
    'minorUnit' => 8,
  ),
  'OGN' => 
  array (
    'symbol' => 'OGN',
    'minorUnit' => 8,
  ),
  'OM' => 
  array (
    'symbol' => 'OM',
    'minorUnit' => 8,
  ),
  'OMG' => 
  array (
    'symbol' => 'OMG',
    'minorUnit' => 8,
  ),
  'ONE' => 
  array (
    'symbol' => 'ONE',
    'minorUnit' => 8,
  ),
  'ONG' => 
  array (
    'symbol' => 'ONG',
    'minorUnit' => 8,
  ),
  'ONT' => 
  array (
    'symbol' => 'ONT',
    'minorUnit' => 8,
  ),
  'OOKI' => 
  array (
    'symbol' => 'OOKI',
    'minorUnit' => 8,
  ),
  'OP' => 
  array (
    'symbol' => 'OP',
    'minorUnit' => 8,
  ),
  'ORN' => 
  array (
    'symbol' => 'ORN',
    'minorUnit' => 8,
  ),
  'OSMO' => 
  array (
    'symbol' => 'OSMO',
    'minorUnit' => 8,
  ),
  'OXT' => 
  array (
    'symbol' => 'OXT',
    'minorUnit' => 8,
  ),
  'PAXG' => 
  array (
    'symbol' => 'PAXG',
    'minorUnit' => 8,
  ),
  'PEOPLE' => 
  array (
    'symbol' => 'PEOPLE',
    'minorUnit' => 8,
  ),
  'PERL' => 
  array (
    'symbol' => 'PERL',
    'minorUnit' => 8,
  ),
  'PERP' => 
  array (
    'symbol' => 'PERP',
    'minorUnit' => 8,
  ),
  'PHA' => 
  array (
    'symbol' => 'PHA',
    'minorUnit' => 8,
  ),
  'PHB' => 
  array (
    'symbol' => 'PHB',
    'minorUnit' => 8,
  ),
  'PIVX' => 
  array (
    'symbol' => 'PIVX',
    'minorUnit' => 8,
  ),
  'PLA' => 
  array (
    'symbol' => 'PLA',
    'minorUnit' => 8,
  ),
  'PNT' => 
  array (
    'symbol' => 'PNT',
    'minorUnit' => 8,
  ),
  'POLS' => 
  array (
    'symbol' => 'POLS',
    'minorUnit' => 8,
  ),
  'POLYX' => 
  array (
    'symbol' => 'POLYX',
    'minorUnit' => 8,
  ),
  'POND' => 
  array (
    'symbol' => 'POND',
    'minorUnit' => 8,
  ),
  'PORTO' => 
  array (
    'symbol' => 'PORTO',
    'minorUnit' => 8,
  ),
  'POWR' => 
  array (
    'symbol' => 'POWR',
    'minorUnit' => 8,
  ),
  'PROM' => 
  array (
    'symbol' => 'PROM',
    'minorUnit' => 8,
  ),
  'PROS' => 
  array (
    'symbol' => 'PROS',
    'minorUnit' => 8,
  ),
  'PSG' => 
  array (
    'symbol' => 'PSG',
    'minorUnit' => 8,
  ),
  'PUNDIX' => 
  array (
    'symbol' => 'PUNDIX',
    'minorUnit' => 8,
  ),
  'PYR' => 
  array (
    'symbol' => 'PYR',
    'minorUnit' => 8,
  ),
  'QI' => 
  array (
    'symbol' => 'QI',
    'minorUnit' => 8,
  ),
  'QKC' => 
  array (
    'symbol' => 'QKC',
    'minorUnit' => 8,
  ),
  'QLC' => 
  array (
    'symbol' => 'QLC',
    'minorUnit' => 8,
  ),
  'QNT' => 
  array (
    'symbol' => 'QNT',
    'minorUnit' => 8,
  ),
  'QTUM' => 
  array (
    'symbol' => 'QTUM',
    'minorUnit' => 8,
  ),
  'QUICK' => 
  array (
    'symbol' => 'QUICK',
    'minorUnit' => 8,
  ),
  'RAD' => 
  array (
    'symbol' => 'RAD',
    'minorUnit' => 8,
  ),
  'RARE' => 
  array (
    'symbol' => 'RARE',
    'minorUnit' => 8,
  ),
  'RAY' => 
  array (
    'symbol' => 'RAY',
    'minorUnit' => 8,
  ),
  'REEF' => 
  array (
    'symbol' => 'REEF',
    'minorUnit' => 8,
  ),
  'REI' => 
  array (
    'symbol' => 'REI',
    'minorUnit' => 8,
  ),
  'REN' => 
  array (
    'symbol' => 'REN',
    'minorUnit' => 8,
  ),
  'REP' => 
  array (
    'symbol' => 'REP',
    'minorUnit' => 8,
  ),
  'REQ' => 
  array (
    'symbol' => 'REQ',
    'minorUnit' => 8,
  ),
  'RIF' => 
  array (
    'symbol' => 'RIF',
    'minorUnit' => 8,
  ),
  'RLC' => 
  array (
    'symbol' => 'RLC',
    'minorUnit' => 8,
  ),
  'RNDR' => 
  array (
    'symbol' => 'RNDR',
    'minorUnit' => 8,
  ),
  'ROSE' => 
  array (
    'symbol' => 'ROSE',
    'minorUnit' => 8,
  ),
  'RSR' => 
  array (
    'symbol' => 'RSR',
    'minorUnit' => 8,
  ),
  'RUNE' => 
  array (
    'symbol' => 'RUNE',
    'minorUnit' => 8,
  ),
  'RVN' => 
  array (
    'symbol' => 'RVN',
    'minorUnit' => 8,
  ),
  'SAND' => 
  array (
    'symbol' => 'SAND',
    'minorUnit' => 8,
  ),
  'SANTOS' => 
  array (
    'symbol' => 'SANTOS',
    'minorUnit' => 8,
  ),
  'SC' => 
  array (
    'symbol' => 'SC',
    'minorUnit' => 8,
  ),
  'SCRT' => 
  array (
    'symbol' => 'SCRT',
    'minorUnit' => 8,
  ),
  'SFP' => 
  array (
    'symbol' => 'SFP',
    'minorUnit' => 8,
  ),
  'SHIB' => 
  array (
    'symbol' => 'SHIB',
    'minorUnit' => 8,
  ),
  'SKL' => 
  array (
    'symbol' => 'SKL',
    'minorUnit' => 8,
  ),
  'SLP' => 
  array (
    'symbol' => 'SLP',
    'minorUnit' => 8,
  ),
  'SNM' => 
  array (
    'symbol' => 'SNM',
    'minorUnit' => 8,
  ),
  'SNT' => 
  array (
    'symbol' => 'SNT',
    'minorUnit' => 8,
  ),
  'SNX' => 
  array (
    'symbol' => 'SNX',
    'minorUnit' => 8,
  ),
  'SOL' => 
  array (
    'symbol' => 'SOL',
    'minorUnit' => 8,
  ),
  'SPELL' => 
  array (
    'symbol' => 'SPELL',
    'minorUnit' => 8,
  ),
  'SRM' => 
  array (
    'symbol' => 'SRM',
    'minorUnit' => 8,
  ),
  'SSV' => 
  array (
    'symbol' => 'SSV',
    'minorUnit' => 8,
  ),
  'STEEM' => 
  array (
    'symbol' => 'STEEM',
    'minorUnit' => 8,
  ),
  'STG' => 
  array (
    'symbol' => 'STG',
    'minorUnit' => 8,
  ),
  'STMX' => 
  array (
    'symbol' => 'STMX',
    'minorUnit' => 8,
  ),
  'STORJ' => 
  array (
    'symbol' => 'STORJ',
    'minorUnit' => 8,
  ),
  'STPT' => 
  array (
    'symbol' => 'STPT',
    'minorUnit' => 8,
  ),
  'STRAX' => 
  array (
    'symbol' => 'STRAX',
    'minorUnit' => 8,
  ),
  'STX' => 
  array (
    'symbol' => 'STX',
    'minorUnit' => 8,
  ),
  'SUN' => 
  array (
    'symbol' => 'SUN',
    'minorUnit' => 8,
  ),
  'SUPER' => 
  array (
    'symbol' => 'SUPER',
    'minorUnit' => 8,
  ),
  'SUSHI' => 
  array (
    'symbol' => 'SUSHI',
    'minorUnit' => 8,
  ),
  'SXP' => 
  array (
    'symbol' => 'SXP',
    'minorUnit' => 8,
  ),
  'SYS' => 
  array (
    'symbol' => 'SYS',
    'minorUnit' => 8,
  ),
  'T' => 
  array (
    'symbol' => 'T',
    'minorUnit' => 8,
  ),
  'TFUEL' => 
  array (
    'symbol' => 'TFUEL',
    'minorUnit' => 8,
  ),
  'THETA' => 
  array (
    'symbol' => 'THETA',
    'minorUnit' => 8,
  ),
  'TKO' => 
  array (
    'symbol' => 'TKO',
    'minorUnit' => 8,
  ),
  'TLM' => 
  array (
    'symbol' => 'TLM',
    'minorUnit' => 8,
  ),
  'TOMO' => 
  array (
    'symbol' => 'TOMO',
    'minorUnit' => 8,
  ),
  'TORN' => 
  array (
    'symbol' => 'TORN',
    'minorUnit' => 8,
  ),
  'TRB' => 
  array (
    'symbol' => 'TRB',
    'minorUnit' => 8,
  ),
  'TRIBE' => 
  array (
    'symbol' => 'TRIBE',
    'minorUnit' => 8,
  ),
  'TROY' => 
  array (
    'symbol' => 'TROY',
    'minorUnit' => 8,
  ),
  'TRU' => 
  array (
    'symbol' => 'TRU',
    'minorUnit' => 8,
  ),
  'TRX' => 
  array (
    'symbol' => 'TRX',
    'minorUnit' => 8,
  ),
  'TVK' => 
  array (
    'symbol' => 'TVK',
    'minorUnit' => 8,
  ),
  'TWT' => 
  array (
    'symbol' => 'TWT',
    'minorUnit' => 8,
  ),
  'UFT' => 
  array (
    'symbol' => 'UFT',
    'minorUnit' => 8,
  ),
  'UMA' => 
  array (
    'symbol' => 'UMA',
    'minorUnit' => 8,
  ),
  'UNFI' => 
  array (
    'symbol' => 'UNFI',
    'minorUnit' => 8,
  ),
  'UNI' => 
  array (
    'symbol' => 'UNI',
    'minorUnit' => 8,
  ),
  'USDT' => 
  array (
    'symbol' => 'USDT',
    'minorUnit' => 8,
  ),
  'USTC' => 
  array (
    'symbol' => 'USTC',
    'minorUnit' => 8,
  ),
  'UTK' => 
  array (
    'symbol' => 'UTK',
    'minorUnit' => 8,
  ),
  'VAI' => 
  array (
    'symbol' => 'VAI',
    'minorUnit' => 8,
  ),
  'VET' => 
  array (
    'symbol' => 'VET',
    'minorUnit' => 8,
  ),
  'VGX' => 
  array (
    'symbol' => 'VGX',
    'minorUnit' => 8,
  ),
  'VIB' => 
  array (
    'symbol' => 'VIB',
    'minorUnit' => 8,
  ),
  'VIDT' => 
  array (
    'symbol' => 'VIDT',
    'minorUnit' => 8,
  ),
  'VITE' => 
  array (
    'symbol' => 'VITE',
    'minorUnit' => 8,
  ),
  'VOXEL' => 
  array (
    'symbol' => 'VOXEL',
    'minorUnit' => 8,
  ),
  'VTHO' => 
  array (
    'symbol' => 'VTHO',
    'minorUnit' => 8,
  ),
  'WABI' => 
  array (
    'symbol' => 'WABI',
    'minorUnit' => 8,
  ),
  'WAN' => 
  array (
    'symbol' => 'WAN',
    'minorUnit' => 8,
  ),
  'WAVES' => 
  array (
    'symbol' => 'WAVES',
    'minorUnit' => 8,
  ),
  'WAXP' => 
  array (
    'symbol' => 'WAXP',
    'minorUnit' => 8,
  ),
  'WBTC' => 
  array (
    'symbol' => 'WBTC',
    'minorUnit' => 8,
  ),
  'WIN' => 
  array (
    'symbol' => 'WIN',
    'minorUnit' => 8,
  ),
  'WING' => 
  array (
    'symbol' => 'WING',
    'minorUnit' => 8,
  ),
  'WNXM' => 
  array (
    'symbol' => 'WNXM',
    'minorUnit' => 8,
  ),
  'WOO' => 
  array (
    'symbol' => 'WOO',
    'minorUnit' => 8,
  ),
  'WRX' => 
  array (
    'symbol' => 'WRX',
    'minorUnit' => 8,
  ),
  'WTC' => 
  array (
    'symbol' => 'WTC',
    'minorUnit' => 8,
  ),
  'XEC' => 
  array (
    'symbol' => 'XEC',
    'minorUnit' => 8,
  ),
  'XEM' => 
  array (
    'symbol' => 'XEM',
    'minorUnit' => 8,
  ),
  'XLM' => 
  array (
    'symbol' => 'XLM',
    'minorUnit' => 8,
  ),
  'XMR' => 
  array (
    'symbol' => 'XMR',
    'minorUnit' => 8,
  ),
  'XNO' => 
  array (
    'symbol' => 'XNO',
    'minorUnit' => 8,
  ),
  'XRP' => 
  array (
    'symbol' => 'XRP',
    'minorUnit' => 8,
  ),
  'XTZ' => 
  array (
    'symbol' => 'XTZ',
    'minorUnit' => 8,
  ),
  'XVG' => 
  array (
    'symbol' => 'XVG',
    'minorUnit' => 8,
  ),
  'XVS' => 
  array (
    'symbol' => 'XVS',
    'minorUnit' => 8,
  ),
  'YFI' => 
  array (
    'symbol' => 'YFI',
    'minorUnit' => 8,
  ),
  'YFII' => 
  array (
    'symbol' => 'YFII',
    'minorUnit' => 8,
  ),
  'YGG' => 
  array (
    'symbol' => 'YGG',
    'minorUnit' => 8,
  ),
  'ZEC' => 
  array (
    'symbol' => 'ZEC',
    'minorUnit' => 8,
  ),
  'ZEN' => 
  array (
    'symbol' => 'ZEN',
    'minorUnit' => 8,
  ),
  'ZIL' => 
  array (
    'symbol' => 'ZIL',
    'minorUnit' => 8,
  ),
  'ZRX' => 
  array (
    'symbol' => 'ZRX',
    'minorUnit' => 8,
  ),
);